from django.apps import AppConfig


class StuscoreConfig(AppConfig):
    name = 'stuscore'
