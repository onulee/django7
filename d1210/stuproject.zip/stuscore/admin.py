from django.contrib import admin
from .models import Stuscore

admin.site.register(Stuscore)

