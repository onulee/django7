from django.contrib import admin
from .models import Member

# 관리자화면 등록
admin.site.register(Member)
